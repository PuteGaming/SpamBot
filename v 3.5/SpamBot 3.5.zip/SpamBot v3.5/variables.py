import hashlib
import random

# version, links, etc.
version = '3.5'
year = '2021'
versionandyear = f'{version}#{year}'
github = 'http://www.github.com/IkonoDim-App-Factory/SpamBot'
owner = 'IkonoDim'

# auth
auth = hashlib.md5(str(random.randint(100, 9999)).encode()).hexdigest()
command = f'.verify {versionandyear}{auth}'
commandondc = '.verify {versionandyear}{auth}'
fullauth = f'{versionandyear}{auth}'