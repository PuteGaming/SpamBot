def SpamBotFiglet():
    print(' ')
    print(' ____                        ____        _ ')
    print('/ ___| _ __   __ _ _ __ ___ | __ )  ___ | |_ ')
    print("\___ \| '_ \ / _` | '_ ` _ \|  _ \ / _ \| __|")
    print(' ___) | |_) | (_| | | | | | | |_) | (_) | |_')
    print('|____/| .__/ \__,_|_| |_| |_|____/ \___/ \__|')
    print('      |_|       ')
    print(' ')


def WelcomeFiglet():
    print('                                               ')
    print('__        _______ _     ____ ___  __  __ _____ ')
    print('\ \      / / ____| |   / ___/ _ \|  \/  | ____|')
    print(' \ \ /\ / /|  _| | |  | |  | | | | |\/| |  _|  ')
    print('  \ V  V / | |___| |__| |__| |_| | |  | | |___ ')
    print('   \_/\_/  |_____|_____\____\___/|_|  |_|_____|')
    print('                                               ')


def WelcomeOwnerFiglet():
    from defs import WelcomeFiglet

    print('-----------------------------------------------')
    WelcomeFiglet()

    print('     _____        ___   _ _____ ____   ')
    print('    / _ \ \      / / \ | | ____|  _ \  ')
    print('   | | | \ \ /\ / /|  \| |  _| | |_) | ')
    print('   | |_| |\ V  V / | |\  | |___|  _ /  ')
    print('    \___/  \_/\_/  |_| \_|_____|_| \_\ ')
    print('                                       ')
    print('-----------------------------------------------')


def log():
    from defs import WelcomeFiglet, WelcomeOwnerFiglet
    import time

    now = time.gmtime()
    now = time.asctime(now)

    WelcomeFiglet()

    username = input('Please enter your Username: ')

    if username == 'IkonoDim':
        WelcomeOwnerFiglet()
        pass
    else:
        pass

    userLog = f'\nLogin at: {now} | username: {username}'
    data1 = open('LOG.txt', mode='a')
    data1.write(userLog)
